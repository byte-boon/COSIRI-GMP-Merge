import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  ClipboardCheck, 
  FileText, 
  AlertTriangle, 
  Settings, 
  LogOut,
  Activity,
  ShieldCheck
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: ClipboardCheck, label: "Assessments", href: "/assessments" },
  { icon: AlertTriangle, label: "Findings & CAPA", href: "/findings" },
  { icon: FileText, label: "Reports", href: "/reports" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 border-r border-sidebar-border bg-sidebar text-sidebar-foreground flex flex-col h-screen fixed left-0 top-0 z-20 transition-all">
      <div className="h-16 flex items-center px-6 border-b border-sidebar-border bg-sidebar-accent/10">
        <ShieldCheck className="w-8 h-8 text-sidebar-primary mr-3" />
        <div>
          <h1 className="font-heading font-bold text-lg tracking-tight">GMP Hub</h1>
          <p className="text-xs text-sidebar-foreground/60">Enterprise Edition</p>
        </div>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1">
        <p className="px-3 text-xs font-medium text-sidebar-foreground/50 uppercase tracking-wider mb-2">Main Menu</p>
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href} className={cn(
                "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-all group",
                isActive 
                  ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm" 
                  : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}>
                <item.icon className={cn("w-5 h-5 mr-3 opacity-70 group-hover:opacity-100", isActive && "opacity-100")} />
                {item.label}
            </Link>
          );
        })}

        <div className="pt-8">
          <p className="px-3 text-xs font-medium text-sidebar-foreground/50 uppercase tracking-wider mb-2">System</p>
          <Link href="/settings" className={cn(
              "flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-all group",
              location === "/settings" 
                ? "bg-sidebar-primary text-sidebar-primary-foreground" 
                : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            )}>
              <Settings className="w-5 h-5 mr-3 opacity-70 group-hover:opacity-100" />
              Configuration
          </Link>
        </div>
      </nav>

      <div className="p-4 border-t border-sidebar-border bg-sidebar-accent/5">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-sidebar-primary/20 flex items-center justify-center text-sidebar-primary font-bold text-xs">
            JW
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">James Wilson</p>
            <p className="text-xs text-sidebar-foreground/60">Lead Auditor</p>
          </div>
          <LogOut className="w-4 h-4 ml-auto text-sidebar-foreground/40 hover:text-destructive cursor-pointer" />
        </div>
      </div>
    </aside>
  );
}
