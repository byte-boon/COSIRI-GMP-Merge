import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { MOCK_SITES, GMP_TEMPLATE } from "@/lib/mock-data";
import { ArrowLeft, Save } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";

export default function NewAssessment() {
  const [_, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      // Navigate to the runner with a new ID (simulated)
      setLocation(`/assessments/audit-new-${Date.now()}`);
    }, 800);
  };

  return (
    <AppLayout>
      <div className="mb-8">
        <Button asChild variant="ghost" size="sm" className="mb-4 pl-0 -ml-2 text-muted-foreground hover:text-foreground">
          <Link href="/assessments">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to List
          </Link>
        </Button>
        <h1 className="text-3xl font-heading font-bold text-foreground">New Assessment</h1>
        <p className="text-muted-foreground mt-1">Initialize a new compliance audit.</p>
      </div>

      <div className="max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Assessment Details</CardTitle>
            <CardDescription>Select the site and standard to begin the audit process.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="scope">Audit Scope / Title</Label>
                <Input id="scope" placeholder="e.g., Q1 Operational Safety Review" required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Site / Facility</Label>
                  <Select required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select site..." />
                    </SelectTrigger>
                    <SelectContent>
                      {MOCK_SITES.map(site => (
                        <SelectItem key={site.id} value={site.id}>{site.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Standard / Template</Label>
                  <Select defaultValue={GMP_TEMPLATE.id} disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="Select template..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={GMP_TEMPLATE.id}>{GMP_TEMPLATE.name}</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-muted-foreground">Only one active template available.</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Lead Auditor</Label>
                <Input value="James Wilson" disabled className="bg-muted text-muted-foreground" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Scheduled Date</Label>
                <Input id="date" type="date" required defaultValue={new Date().toISOString().split('T')[0]} />
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <Button asChild variant="outline" type="button">
                  <Link href="/assessments">Cancel</Link>
                </Button>
                <Button type="submit" disabled={isLoading} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  {isLoading ? "Creating..." : "Start Assessment"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
