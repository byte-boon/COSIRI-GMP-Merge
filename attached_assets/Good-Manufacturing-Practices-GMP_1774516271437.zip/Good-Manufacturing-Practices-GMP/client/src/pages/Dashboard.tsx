import { MOCK_ASSESSMENTS, MOCK_FINDINGS } from "@/lib/mock-data";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { ArrowUpRight, TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const recentAudit = MOCK_ASSESSMENTS[0];
  const complianceData = [
    { name: 'Leadership', score: 85, fill: 'hsl(var(--chart-1))' },
    { name: 'Workforce', score: 92, fill: 'hsl(var(--chart-2))' },
    { name: 'Infrastructure', score: 78, fill: 'hsl(var(--chart-3))' },
    { name: 'Security', score: 65, fill: 'hsl(var(--warning))' },
    { name: 'Operations', score: 88, fill: 'hsl(var(--chart-1))' },
  ];

  const findingsData = [
    { name: 'Critical', value: 1, color: 'hsl(var(--destructive))' },
    { name: 'Major', value: 3, color: 'hsl(var(--warning))' },
    { name: 'Minor', value: 8, color: 'hsl(var(--chart-2))' },
  ];

  return (
    <AppLayout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Overview</h1>
          <p className="text-muted-foreground mt-1">Welcome back, Auditor Wilson. You have 2 active assessments.</p>
        </div>
        <div className="flex gap-3">
           <Link href="/assessments/new" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 shadow-sm">
              New Assessment
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="hover-elevate shadow-sm border-l-4 border-l-primary">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Compliance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87.5%</div>
            <p className="text-xs text-muted-foreground">+2.1% from last month</p>
          </CardContent>
        </Card>
        <Card className="hover-elevate shadow-sm border-l-4 border-l-destructive">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Critical NCs</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">1</div>
            <p className="text-xs text-muted-foreground">Requires immediate attention</p>
          </CardContent>
        </Card>
        <Card className="hover-elevate shadow-sm border-l-4 border-l-warning">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue CAPAs</CardTitle>
            <Clock className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">3</div>
            <p className="text-xs text-muted-foreground">Across 2 sites</p>
          </CardContent>
        </Card>
        <Card className="hover-elevate shadow-sm border-l-4 border-l-success">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Audits Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Year to date</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="col-span-2 shadow-sm">
          <CardHeader>
            <CardTitle>Compliance by Section (Global)</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={complianceData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={100} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: 'var(--radius)' }}
                  cursor={{fill: 'transparent'}}
                />
                <Bar dataKey="score" radius={[0, 4, 4, 0]} barSize={32}>
                  {complianceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-1 shadow-sm">
          <CardHeader>
            <CardTitle>Findings Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px] flex justify-center items-center">
             <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={findingsData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {findingsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Assessments</CardTitle>
          <Link href="/assessments">
            <a className="text-sm text-primary hover:underline flex items-center">
              View All <ArrowUpRight className="w-4 h-4 ml-1" />
            </a>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {MOCK_ASSESSMENTS.map((audit) => (
              <div key={audit.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/30 transition-colors">
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "w-2 h-12 rounded-full",
                    audit.status === 'Closed' ? 'bg-success' : 'bg-primary'
                  )} />
                  <div>
                    <h4 className="font-semibold text-foreground">{audit.scope}</h4>
                    <p className="text-sm text-muted-foreground">{audit.id} • Started {audit.startDate}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className={cn(
                      "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                      audit.status === 'Closed' ? "bg-success/10 text-success" : "bg-primary/10 text-primary"
                    )}>
                      {audit.status}
                    </span>
                    <p className="text-sm font-bold mt-1 text-foreground">{audit.overallScore}% Score</p>
                  </div>
                  <Link href={`/assessments/${audit.id}`}>
                    <a className="p-2 hover:bg-muted rounded-full text-muted-foreground hover:text-foreground">
                      <ArrowUpRight className="w-5 h-5" />
                    </a>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </AppLayout>
  );
}
