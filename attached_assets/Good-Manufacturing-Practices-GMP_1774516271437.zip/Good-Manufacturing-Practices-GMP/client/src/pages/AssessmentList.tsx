import { AppLayout } from "@/components/layout/AppLayout";
import { MOCK_ASSESSMENTS, MOCK_SITES } from "@/lib/mock-data";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter, Plus } from "lucide-react";

export default function AssessmentList() {
  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Assessments</h1>
          <p className="text-muted-foreground mt-1">Manage and track GMP audits across all sites.</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              type="search" 
              placeholder="Search assessments..." 
              className="pl-9 bg-card"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
            <Link href="/assessments/new">
              <Plus className="h-4 w-4" /> New Audit
            </Link>
          </Button>
        </div>
      </div>

      <div className="bg-card border rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-muted/50 text-muted-foreground border-b uppercase text-xs font-medium">
              <tr>
                <th className="px-6 py-4">Audit ID / Scope</th>
                <th className="px-6 py-4">Site</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Auditor</th>
                <th className="px-6 py-4">Score</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {MOCK_ASSESSMENTS.map((assessment) => {
                const site = MOCK_SITES.find(s => s.id === assessment.siteId);
                return (
                  <tr key={assessment.id} className="hover:bg-muted/30 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-foreground">{assessment.scope}</div>
                      <div className="text-xs text-muted-foreground font-mono">{assessment.id}</div>
                    </td>
                    <td className="px-6 py-4 text-foreground">
                      {site?.name || 'Unknown Site'}
                      <div className="text-xs text-muted-foreground">{site?.location}</div>
                    </td>
                    <td className="px-6 py-4 text-foreground font-medium">
                      {assessment.startDate}
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      James Wilson
                    </td>
                    <td className="px-6 py-4">
                      {assessment.status === 'Closed' ? (
                        <span className={cn(
                          "font-bold",
                          assessment.overallScore >= 90 ? "text-success" : 
                          assessment.overallScore >= 80 ? "text-primary" : "text-warning"
                        )}>
                          {assessment.overallScore}%
                        </span>
                      ) : (
                        <span className="text-muted-foreground italic">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className={cn(
                        assessment.status === 'Closed' && "bg-success/10 text-success border-success/20",
                        assessment.status === 'InProgress' && "bg-primary/10 text-primary border-primary/20",
                        assessment.status === 'Draft' && "bg-muted text-muted-foreground",
                      )}>
                        {assessment.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Button asChild size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link href={`/assessments/${assessment.id}`}>
                          Open
                        </Link>
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
