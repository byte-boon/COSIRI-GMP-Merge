import { useState, useMemo } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { GMP_TEMPLATE, MOCK_ASSESSMENTS } from "@/lib/mock-data";
import { cn } from "@/lib/utils";
import { 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  MinusCircle, 
  ChevronRight, 
  Save, 
  FileText,
  Camera,
  Paperclip,
  Flag,
  ArrowLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link, useRoute } from "wouter";
import { ComplianceStatus, Criticality, Response, TemplateSection, TemplateItem } from "@/types";

export default function AssessmentRunner() {
  const [_, params] = useRoute("/assessments/:id");
  const assessmentId = params?.id;
  const assessment = MOCK_ASSESSMENTS.find(a => a.id === assessmentId) || MOCK_ASSESSMENTS[0];

  const [activeSectionId, setActiveSectionId] = useState(GMP_TEMPLATE.sections[0].id);
  const [responses, setResponses] = useState<Record<string, Response>>(assessment.responses || {});

  const activeSection = GMP_TEMPLATE.sections.find((s: TemplateSection) => s.id === activeSectionId);

  // Calculate Progress
  const totalItems = GMP_TEMPLATE.sections.reduce((acc: number, sec: TemplateSection) => acc + sec.items.length, 0);
  const answeredItems = Object.keys(responses).length;
  const progressPercent = Math.round((answeredItems / totalItems) * 100);

  const handleResponse = (itemId: string, status: ComplianceStatus, score: number) => {
    setResponses(prev => ({
      ...prev,
      [itemId]: { 
        ...prev[itemId], 
        itemId, 
        status, 
        score,
        // Reset finding details if moving to compliant
        ...(status === 'Compliant' ? { comment: '', riskLikelihood: undefined, riskImpact: undefined } : {})
      }
    }));
  };

  const getStatusColor = (status?: ComplianceStatus) => {
    switch(status) {
      case 'Compliant': return 'text-success bg-success/10 border-success/20';
      case 'Partial': return 'text-warning bg-warning/10 border-warning/20';
      case 'Noncompliant': return 'text-destructive bg-destructive/10 border-destructive/20';
      case 'NotApplicable': return 'text-muted-foreground bg-muted border-muted';
      default: return 'text-muted-foreground border-transparent';
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background font-sans">
      {/* 1. Left Sidebar: Navigation & Progress */}
      <aside className="w-80 border-r border-border bg-card flex flex-col z-10 shadow-lg">
        <div className="p-4 border-b border-border bg-sidebar text-sidebar-foreground">
          <Link href="/assessments">
             <Button variant="ghost" size="sm" className="mb-4 text-sidebar-foreground/70 hover:text-white pl-0 -ml-2">
              <ArrowLeft className="w-4 h-4 mr-1" /> Back to List
            </Button>
          </Link>
          <div className="mb-4">
            <h2 className="font-heading font-bold text-lg">{assessment.scope}</h2>
            <p className="text-xs opacity-70 font-mono mt-1">{assessment.id}</p>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-medium uppercase tracking-wider opacity-80">
              <span>Progress</span>
              <span>{progressPercent}%</span>
            </div>
            <Progress value={progressPercent} className="h-2 bg-sidebar-accent/50 [&>div]:bg-success" />
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 space-y-1">
            {GMP_TEMPLATE.sections.map((section: TemplateSection, idx: number) => {
              const isActive = section.id === activeSectionId;
              // Calculate section completion
              const sectionItems = section.items.map((i: TemplateItem) => i.id);
              const completedCount = sectionItems.filter((id: string) => responses[id]).length;
              const isComplete = completedCount === sectionItems.length;

              return (
                <button
                  key={section.id}
                  onClick={() => setActiveSectionId(section.id)}
                  className={cn(
                    "w-full text-left px-3 py-3 rounded-md text-sm transition-all flex items-start gap-3 group relative",
                    isActive 
                      ? "bg-primary/10 text-primary font-medium" 
                      : "text-muted-foreground hover:bg-muted"
                  )}
                >
                  <div className={cn(
                    "w-1 h-full absolute left-0 top-0 rounded-l-md transition-colors",
                    isActive ? "bg-primary" : "bg-transparent"
                  )} />
                  
                  <div className="mt-0.5">
                    {isComplete ? (
                      <CheckCircle2 className="w-4 h-4 text-success" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30 text-[10px] flex items-center justify-center font-mono group-hover:border-foreground/50">
                        {idx + 1}
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <span className="line-clamp-1">{section.title}</span>
                    <span className="text-xs opacity-60 font-normal block mt-0.5">
                      {completedCount}/{sectionItems.length} items
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </aside>

      {/* 2. Main Content: Checklist Items */}
      <main className="flex-1 overflow-y-auto bg-muted/10 relative">
        <div className="max-w-4xl mx-auto p-8 pb-32">
          {activeSection && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <header className="mb-8 pb-4 border-b border-border">
                <Badge variant="outline" className="mb-2 bg-background">Section {GMP_TEMPLATE.sections.findIndex((s: TemplateSection) => s.id === activeSectionId) + 1}</Badge>
                <h1 className="text-3xl font-heading font-bold text-foreground">{activeSection.title}</h1>
              </header>

              <div className="space-y-6">
                {activeSection.items.map((item: TemplateItem) => {
                  const response = responses[item.id];
                  const isCritical = item.criticality === 'Critical';
                  
                  return (
                    <div 
                      key={item.id} 
                      id={`item-${item.id}`}
                      className={cn(
                        "bg-card border rounded-lg shadow-sm transition-all",
                        isCritical ? "border-l-4 border-l-destructive" : "border-l-4 border-l-transparent hover:border-l-primary/50"
                      )}
                    >
                      <div className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex gap-3">
                            <span className="font-mono text-xs font-bold text-muted-foreground bg-muted px-2 py-1 rounded h-fit">
                              {item.code}
                            </span>
                            <div>
                              <p className="text-base font-medium text-foreground leading-snug">{item.question}</p>
                              <p className="text-sm text-muted-foreground mt-1">{item.guidance}</p>
                            </div>
                          </div>
                          {isCritical && (
                            <Badge variant="destructive" className="ml-4 shrink-0 uppercase text-[10px] tracking-widest">Critical</Badge>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {[
                            { label: 'Compliant', value: 'Compliant', score: 4, icon: CheckCircle2, color: 'text-success hover:bg-success/10 hover:text-success hover:border-success/50' },
                            { label: 'Partial', value: 'Partial', score: 2, icon: AlertCircle, color: 'text-warning hover:bg-warning/10 hover:text-warning hover:border-warning/50' },
                            { label: 'Non-Compliant', value: 'Noncompliant', score: 0, icon: XCircle, color: 'text-destructive hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50' },
                            { label: 'N/A', value: 'NotApplicable', score: 0, icon: MinusCircle, color: 'text-muted-foreground hover:bg-muted hover:text-foreground' },
                          ].map((opt) => {
                            const isSelected = response?.status === opt.value;
                            return (
                              <button
                                key={opt.value}
                                onClick={() => handleResponse(item.id, opt.value as ComplianceStatus, opt.score)}
                                className={cn(
                                  "flex items-center gap-2 px-4 py-2 rounded-md border text-sm font-medium transition-all",
                                  isSelected 
                                    ? cn("ring-2 ring-offset-1 ring-offset-background", opt.color.split(' ')[0], opt.color.includes('success') ? 'bg-success/10 border-success' : opt.color.includes('warning') ? 'bg-warning/10 border-warning' : opt.color.includes('destructive') ? 'bg-destructive/10 border-destructive' : 'bg-muted border-foreground/20')
                                    : "bg-background border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
                                )}
                              >
                                <opt.icon className="w-4 h-4" />
                                {opt.label}
                              </button>
                            );
                          })}
                        </div>

                        {/* Extended Inputs for Non-Compliant/Partial */}
                        {(response?.status === 'Partial' || response?.status === 'Noncompliant') && (
                          <div className="mt-4 pt-4 border-t border-dashed animate-in slide-in-from-top-2">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="space-y-1.5">
                                <label className="text-xs font-medium text-muted-foreground">Likelihood (1-5)</label>
                                <div className="flex gap-1">
                                  {[1,2,3,4,5].map(v => (
                                    <button 
                                      key={v}
                                      onClick={() => setResponses(prev => ({...prev, [item.id]: {...prev[item.id], riskLikelihood: v}}))}
                                      className={cn(
                                        "w-8 h-8 rounded text-sm font-bold transition-colors",
                                        response.riskLikelihood === v ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                                      )}
                                    >
                                      {v}
                                    </button>
                                  ))}
                                </div>
                              </div>
                              <div className="space-y-1.5">
                                <label className="text-xs font-medium text-muted-foreground">Impact (1-5)</label>
                                <div className="flex gap-1">
                                  {[1,2,3,4,5].map(v => (
                                    <button 
                                      key={v}
                                      onClick={() => setResponses(prev => ({...prev, [item.id]: {...prev[item.id], riskImpact: v}}))}
                                      className={cn(
                                        "w-8 h-8 rounded text-sm font-bold transition-colors",
                                        response.riskImpact === v ? "bg-destructive text-destructive-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"
                                      )}
                                    >
                                      {v}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <div className="space-y-2">
                               <label className="text-xs font-medium text-muted-foreground flex items-center gap-2">
                                 <Flag className="w-3 h-3" /> Observation / Finding Details
                               </label>
                               <Textarea 
                                 placeholder="Describe the non-conformance..." 
                                 className="min-h-[80px] text-sm resize-none"
                                 value={response.comment || ''}
                                 onChange={(e) => setResponses(prev => ({...prev, [item.id]: {...prev[item.id], comment: e.target.value}}))}
                               />
                            </div>
                          </div>
                        )}
                        
                        {/* Evidence & Tools Footer */}
                        <div className="mt-4 pt-3 flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex gap-4">
                            <button className="flex items-center gap-1 hover:text-primary transition-colors">
                              <Paperclip className="w-3.5 h-3.5" /> Attach Evidence
                            </button>
                            <button className="flex items-center gap-1 hover:text-primary transition-colors">
                              <Camera className="w-3.5 h-3.5" /> Add Photo
                            </button>
                          </div>
                          {response?.status && (
                            <span className="font-mono opacity-50">Score: {response.score}/4</span>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-8 flex justify-between items-center">
                 <Button variant="outline" size="lg" disabled={activeSectionId === GMP_TEMPLATE.sections[0].id}>
                    Previous Section
                 </Button>
                 <Button size="lg" className="bg-primary text-primary-foreground shadow-lg shadow-primary/20">
                    Next Section <ChevronRight className="ml-2 w-4 h-4" />
                 </Button>
              </div>
            </div>
          )}
        </div>
      </main>

    </div>
  );
}
