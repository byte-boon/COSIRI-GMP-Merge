import { AppLayout } from "@/components/layout/AppLayout";
import { MOCK_FINDINGS, MOCK_ASSESSMENTS } from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Search, Filter, AlertTriangle, Info, CheckCircle, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function FindingsList() {
  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">Findings & CAPA</h1>
          <p className="text-muted-foreground mt-1">Track non-conformities and corrective actions.</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              type="search" 
              placeholder="Search findings..." 
              className="pl-9 bg-card"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {MOCK_FINDINGS.map((finding) => {
          const assessment = MOCK_ASSESSMENTS.find(a => a.id === finding.assessmentId);
          return (
            <div key={finding.id} className="bg-card border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="flex gap-4">
                  <div className={cn(
                    "p-3 rounded-full h-fit shrink-0",
                    finding.severity === 'Critical' ? "bg-destructive/10 text-destructive" :
                    finding.severity === 'Major' ? "bg-warning/10 text-warning" :
                    "bg-primary/10 text-primary"
                  )}>
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <Badge variant="outline" className={cn(
                        "uppercase text-[10px] tracking-wider",
                        finding.severity === 'Critical' ? "border-destructive text-destructive" :
                        finding.severity === 'Major' ? "border-warning text-warning" :
                        "border-primary text-primary"
                      )}>
                        {finding.severity}
                      </Badge>
                      <span className="text-xs text-muted-foreground font-mono">{finding.id}</span>
                      <span className="text-xs text-muted-foreground">• {finding.type}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">{finding.description}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Ref: Item {finding.itemId}</span>
                      <span>•</span>
                      <span>{assessment?.scope || assessment?.id}</span>
                      <span>•</span>
                      <span>Created {finding.createdAt}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-end gap-3 min-w-[200px]">
                  <Badge variant={finding.status === 'Open' ? 'secondary' : 'outline'} className="mb-2">
                    {finding.status}
                  </Badge>
                  <Button size="sm" variant="outline" className="w-full md:w-auto">
                    Manage CAPA <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </AppLayout>
  );
}
