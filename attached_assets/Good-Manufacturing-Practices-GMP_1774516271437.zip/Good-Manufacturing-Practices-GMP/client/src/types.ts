export type Criticality = 'Critical' | 'Major' | 'Minor';
export type AssessmentStatus = 'Draft' | 'InProgress' | 'Review' | 'Closed';
export type ComplianceStatus = 'Compliant' | 'Partial' | 'Noncompliant' | 'NotApplicable';
export type FindingType = 'NC' | 'Observation' | 'Opportunity';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Auditor' | 'SiteManager';
  avatar?: string;
}

export interface Site {
  id: string;
  name: string;
  location: string;
  organization: string;
}

export interface TemplateItem {
  id: string;
  code: string;
  question: string;
  guidance: string;
  criticality: Criticality;
  weight: number;
}

export interface TemplateSection {
  id: string;
  title: string;
  items: TemplateItem[];
}

export interface Template {
  id: string;
  name: string;
  version: string;
  sections: TemplateSection[];
}

export interface Response {
  itemId: string;
  score: number; // 0-4
  status: ComplianceStatus;
  comment?: string;
  riskLikelihood?: number; // 1-5
  riskImpact?: number; // 1-5
}

export interface Assessment {
  id: string;
  siteId: string;
  templateId: string;
  auditorId: string;
  startDate: string;
  status: AssessmentStatus;
  scope: string;
  overallScore: number;
  responses: Record<string, Response>; // itemId -> Response
}

export interface Finding {
  id: string;
  assessmentId: string;
  itemId: string;
  type: FindingType;
  severity: Criticality;
  description: string;
  status: 'Open' | 'Closed';
  createdAt: string;
}

export interface CAPA {
  id: string;
  findingId: string;
  description: string;
  owner: string;
  dueDate: string;
  status: 'Open' | 'InProgress' | 'Implemented' | 'Verified';
}
