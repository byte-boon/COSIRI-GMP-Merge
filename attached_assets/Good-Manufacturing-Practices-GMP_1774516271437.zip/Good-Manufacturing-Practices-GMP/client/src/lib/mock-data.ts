import { Assessment, CAPA, Finding, Site, Template, User } from "../types";

export const MOCK_USERS: User[] = [
  { id: '1', name: 'Sarah Chen', email: 'sarah.c@corp-audit.com', role: 'Admin', avatar: 'SC' },
  { id: '2', name: 'James Wilson', email: 'j.wilson@corp-audit.com', role: 'Auditor', avatar: 'JW' },
];

export const MOCK_SITES: Site[] = [
  { id: '1', name: 'North American Logistics Hub', location: 'Chicago, IL', organization: 'Global Industries Inc.' },
  { id: '2', name: 'Primary Manufacturing Plant', location: 'Austin, TX', organization: 'Global Industries Inc.' },
  { id: '3', name: 'EMEA Regional Office', location: 'London, UK', organization: 'Global Industries Inc.' },
];

export const GMP_TEMPLATE: Template = {
  id: 'tmpl-001',
  name: 'Corporate Operational Excellence Standard v2.1',
  version: '2.1',
  sections: [
    {
      id: 'sec-1',
      title: '1. Leadership & Governance',
      items: [
        { id: '1.1', code: 'GOV.01', question: 'Are business continuity plans documented and tested annually?', guidance: 'Review BCP documents and test reports from the last 12 months.', criticality: 'Major', weight: 2 },
        { id: '1.2', code: 'GOV.02', question: 'Is there a defined organizational chart with clear roles and responsibilities?', guidance: 'Verify current org chart is available to all employees.', criticality: 'Minor', weight: 1 },
        { id: '1.3', code: 'GOV.03', question: 'Are internal audits conducted according to the annual schedule?', guidance: 'Check audit calendar vs actual completion dates.', criticality: 'Major', weight: 2 },
      ]
    },
    {
      id: 'sec-2',
      title: '2. Workforce & Safety (EHS)',
      items: [
        { id: '2.1', code: 'EHS.01', question: 'Are all employees trained on relevant safety protocols (fire, ergonomics, PPE)?', guidance: 'Sample 5 training records for recent hires.', criticality: 'Critical', weight: 3 },
        { id: '2.2', code: 'EHS.02', question: 'Are emergency exits clearly marked and unobstructed?', guidance: 'Walkthrough of facility floor and office areas.', criticality: 'Critical', weight: 3 },
        { id: '2.3', code: 'EHS.03', question: 'Is there a formal incident reporting mechanism in place?', guidance: 'Interview 2 employees on how they would report a near-miss.', criticality: 'Major', weight: 2 },
      ]
    },
    {
      id: 'sec-3',
      title: '3. Operations & Infrastructure',
      items: [
        { id: '3.1', code: 'OPS.01', question: 'Is critical equipment maintained according to manufacturer schedules?', guidance: 'Check maintenance logs for key machinery/IT servers.', criticality: 'Major', weight: 2 },
        { id: '3.2', code: 'OPS.02', question: 'Are facility access controls (badges, locks) functioning correctly?', guidance: 'Test entry points and review access logs.', criticality: 'Major', weight: 2 },
        { id: '3.3', code: 'OPS.03', question: 'Is the workplace clean and organized (5S principles)?', guidance: 'Visual inspection of desks, floors, and storage areas.', criticality: 'Minor', weight: 1 },
      ]
    },
    {
      id: 'sec-4',
      title: '4. Information Security & Data',
      items: [
        { id: '4.1', code: 'SEC.01', question: 'Is multi-factor authentication (MFA) enforced for all company accounts?', guidance: 'Verify IT policy and system settings.', criticality: 'Critical', weight: 3 },
        { id: '4.2', code: 'SEC.02', question: 'Are data backups performed and verified daily?', guidance: 'Check backup logs for the last 7 days.', criticality: 'Critical', weight: 3 },
      ]
    }
  ]
};

export const MOCK_ASSESSMENTS: Assessment[] = [
  {
    id: 'audit-2024-001',
    siteId: '1',
    templateId: 'tmpl-001',
    auditorId: '2',
    startDate: '2024-02-10',
    status: 'InProgress',
    scope: 'Annual Site Operations Review',
    overallScore: 88,
    responses: {
      '1.1': { itemId: '1.1', score: 4, status: 'Compliant' },
      '1.2': { itemId: '1.2', score: 3, status: 'Partial', comment: 'Org chart exists but is 6 months outdated.', riskLikelihood: 2, riskImpact: 1 },
      '1.3': { itemId: '1.3', score: 4, status: 'Compliant' },
      '2.1': { itemId: '2.1', score: 4, status: 'Compliant' },
    }
  },
  {
    id: 'audit-2023-099',
    siteId: '2',
    templateId: 'tmpl-001',
    auditorId: '2',
    startDate: '2023-12-05',
    status: 'Closed',
    scope: 'Q4 Safety & Security Audit',
    overallScore: 94,
    responses: {}
  }
];

export const MOCK_FINDINGS: Finding[] = [
  {
    id: 'f-001',
    assessmentId: 'audit-2024-001',
    itemId: '1.2',
    type: 'Observation',
    severity: 'Minor',
    description: 'The organizational chart posted in the break room lists former employees.',
    status: 'Open',
    createdAt: '2024-02-10'
  },
  {
    id: 'f-002',
    assessmentId: 'audit-2023-099',
    itemId: '2.2',
    type: 'NC',
    severity: 'Major',
    description: 'Emergency exit in Warehouse Zone B was blocked by a pallet.',
    status: 'Closed',
    createdAt: '2023-12-05'
  }
];

export const MOCK_CAPAS: CAPA[] = [
  {
    id: 'c-001',
    findingId: 'f-001',
    description: 'Update all physical and digital organizational charts to reflect Q1 staffing.',
    owner: 'HR Manager',
    dueDate: '2024-03-01',
    status: 'InProgress'
  }
];
