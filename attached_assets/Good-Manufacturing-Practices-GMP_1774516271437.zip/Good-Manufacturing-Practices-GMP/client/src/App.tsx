import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import AssessmentList from "@/pages/AssessmentList";
import AssessmentRunner from "@/pages/AssessmentRunner";
import FindingsList from "@/pages/FindingsList";
import NewAssessment from "@/pages/NewAssessment";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/assessments" component={AssessmentList} />
      <Route path="/assessments/new" component={NewAssessment} /> 
      <Route path="/assessments/:id" component={AssessmentRunner} />
      <Route path="/findings" component={FindingsList} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
